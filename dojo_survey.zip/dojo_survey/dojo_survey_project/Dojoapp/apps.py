from django.apps import AppConfig


class DojoappConfig(AppConfig):
    name = 'Dojoapp'
